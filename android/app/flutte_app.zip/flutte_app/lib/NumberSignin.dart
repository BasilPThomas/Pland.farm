import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';

class NumberSignin extends StatefulWidget {
  @override
  _NumberSigninState createState() => _NumberSigninState();
}

class _NumberSigninState extends State<NumberSignin> {

  PhoneNumber _phoneNumber;
  String _message;
  String _verificationId;

  bool _isSMSsent = false;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final TextEditingController _smsController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _numberController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("images/first.jpg"),
                fit: BoxFit.fill)),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // SizedBox(height:getProportionateScreenWidth(100),),
              Container(
                  margin: EdgeInsets.only(top: 60),
                  child: Image.asset('images/image.png', height: 90,)),
              Center(
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  height: 430,
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(30)),
                    color: Colors.white.withOpacity(0.5),
                  ),
                  child: SingleChildScrollView(
                    child:
                        Container(
                          margin: EdgeInsets.only(top: 30, right: 5, left: 5, bottom: 10),
                          child: Column(
                            children: [
                              Text(
                                "WELCOME BACK",
                                style: TextStyle(color: Colors.green[900],
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,),
                              ),
                              Text(
                                "Sign In with your Mobile number",
                                textAlign: TextAlign.center,
                              ),
                               AnimatedContainer(
                                duration: Duration(milliseconds: 500),
                                margin: EdgeInsets.only(top: 20, right: 10, left: 10, bottom: 10),
                                 child: Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Text(
                                    //   "Mobile number",
                                    //   style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold,),
                                    //   textAlign: TextAlign.left,
                                    // ),
                                    SizedBox(height: 20,),
                                    TextField(
                                      controller: _nameController,
                                      keyboardType: TextInputType.name,
                                      decoration: InputDecoration(
                                          fillColor: Colors.white,
                                          hintText: "Enter your name",
                                          floatingLabelBehavior: FloatingLabelBehavior
                                              .always,
                                          border: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(30.0)))
                                      ),),
                                    SizedBox(height: 20,),
                                    Container(
                                      margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                                      child: InternationalPhoneNumberInput(
                                        onInputChanged: (phoneNumberTxt){
                                          _phoneNumber = phoneNumberTxt;
                                          print(phoneNumberTxt);
                                        },
                                        inputBorder: OutlineInputBorder(),
                                      ),
                                    ),
                                    // TextField(
                                    //   controller: _numberController,
                                    //   keyboardType: TextInputType.number,
                                    //   decoration: InputDecoration(
                                    //       fillColor: Colors.white,
                                    //       hintText: "Enter your number",
                                    //       floatingLabelBehavior: FloatingLabelBehavior
                                    //           .always,
                                    //       border: OutlineInputBorder(
                                    //           borderRadius: BorderRadius.all(
                                    //               Radius.circular(30.0)))
                                    //   ),),
                                    _isSMSsent?Container(
                                      margin: EdgeInsets.all(10),
                                      child: TextField(
                                        controller: _smsController,
                                        decoration:InputDecoration(
                                          border: OutlineInputBorder(),
                                          hintText: "OTP here",
                                          labelText: "OTP",
                                        ),
                                        maxLength: 4,
                                        keyboardType: TextInputType.number,
                                      ),
                                    ):Container(),
                                    !_isSMSsent?InkWell(
                                      onTap: () {
                                        setState(() {
                                          _isSMSsent =true;
                                        });
                                        _verifyPhoneNumber();
                                      },
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        margin: EdgeInsets.symmetric(vertical: 5, horizontal: 30) ,
                                        padding: EdgeInsets.symmetric(vertical: 8, horizontal: 20),
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(15)),
                                          color: Colors.green[400],
                                        ),
                                        child: Text(
                                          'Sign In',
                                          style: TextStyle(
                                              fontSize: 25,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white),
                                        ),),
                                    ):InkWell(
                                      onTap: () {
                                        _signInwithPhoneNumber();
                                      },
                                      child: Container(
                                        width: MediaQuery.of(context).size.width,
                                        margin: EdgeInsets.symmetric(vertical: 8, horizontal: 20) ,
                                        padding: EdgeInsets.symmetric(vertical: 8, horizontal: 20),
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(15)),
                                          color: Colors.green[400],
                                        ),
                                        child: Text(
                                          'Verify otp',
                                          style: TextStyle(
                                              fontSize: 25,
                                              fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),),
                                  )
                          ],
                        ),
                      ),
               ] ),
              ),
                )
              ),
          ),
        ]),)
      ),
    );
  }

  void _verifyPhoneNumber() async {
    setState(() {
      _message = '';
    });

    // final PhoneAuthProvider authProvider =
    // var applicationVerifier = new firebase.auth.RecaptchaVerifier(
    //     'recaptcha-container');
    // var provider = new firebase.auth.PhoneAuthProvider();
    // provider.verifyPhoneNumber('+16505550101', applicationVerifier)
    //     .then(function(verificationId) {
    // var verificationCode = window.prompt('Please enter the verification ' +
    // 'code that was sent to your mobile device.');
    // return firebase.auth.PhoneAuthProvider.credential(verificationId,
    // verificationCode);
    // })
    //     .then(function(phoneCredential) {
    // return firebase.auth().signInWithCredential(phoneCredential);
    // });

    final PhoneVerificationCompleted verificationCompleted =
      (AuthCredential phoneAuthCredential) {
      _auth.signInWithCredential(phoneAuthCredential);
      setState(() {
        _message ='Received phone auth credential: $phoneAuthCredential';
      });
      };

    final PhoneVerificationFailed verificationFailed =
    (AuthException authException) {
      setState(() {
        _message =
            'Phone number verification failed. Code: ${authException.code}.message: ${authException.message}';
      });
    };

    f

    final PhoneCodeSent codeSent =
    (String verificationId, [int forceResendingToken]) async {
      _verificationId = verificationId;
    };

    final PhoneCodeAutoRetrievalTimeout codeAutoRetrievalTimeout =
    (String verificationId) {
      _verificationId = verificationId;
    };

    await _auth.verifyPhoneNumber(
        phoneNumber: _phoneNumber.phoneNumber,
        timeout: const Duration(seconds: 200),
        verificationCompleted: verificationCompleted,
        verificationFailed: verificationFailed,
        codeSent: codeSent,
        codeAutoRetrievalTimeout: codeAutoRetrievalTimeout);
  }

  void _signInwithPhoneNumber() async {
    final AuthCredential credential = PhoneAuthProvider.getCredential(
        verificationId: _verificationId, smsCode: _smsController.text);
    final FirebaseUser user =
     (await _auth.signInWithCredential(credential)).user;
    final FirebaseUser currentUser = await _auth.currentUser();
    assert(user.uid == currentUser.uid);
    setState(() {
      if(user != null){
        _message = 'Successfully signed in, uid: '+user.uid;
      }else{
        _message = 'sign in failed';
      }
    });
  }
}
